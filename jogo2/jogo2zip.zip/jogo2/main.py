from __future__ import division
import pygame
import random
from os import path

# diretorio das imagens/sons
img_dir = path.join(path.dirname(__file__), 'imagens')
sons_dir = path.join(path.dirname(__file__), 'sons')

LAR = 480
ALTURA = 600
DT = 60
POWERUP_TEMPO = 5000
BAR_LAR = 100
BAR_ALTURA = 10
branco = (255, 255, 255)
preto = (0, 0, 0)
vermelho = (255, 0, 0)
verde = (0, 255, 0)
azul = (0, 0, 255)
amarelo = (255, 255, 0)


#começar o jogo e criar janela
pygame.init()
pygame.mixer.init()  
screen = pygame.display.set_mode((LAR, ALTURA))
pygame.display.set_caption("The Corona Shooter")
clock = pygame.time.Clock()

font_name = pygame.font.match_font('arial')

def menu_principal():
    global screen

    menu_som = pygame.mixer.music.load(path.join(sons_dir, "1.wav"))
    pygame.mixer.music.play(-1)

    title = pygame.image.load(path.join(img_dir, "main.png")).convert()
    title = pygame.transform.scale(title, (LAR, ALTURA), screen)

    screen.blit(title, (0,0))
    pygame.display.update()

    while True:
        evento = pygame.event.poll()
        if evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_RETURN:
                break
            elif evento.key == pygame.K_q:
                pygame.quit()
                quit()
        elif evento.type == pygame.QUIT:
                pygame.quit()
                quit() 
        else:
            desenha_texto(screen, "Aperte [ENTER] para começar", 30, LAR/2, ALTURA/2)
            desenha_texto(screen, "ou [Q] para sair", 30, LAR/2, (ALTURA/2)+40)
            pygame.display.update()

    # pronto = pygame.mixer.Sound(path.join(sons_dir,'se_prepare.wav'))
    # pronto.play()
    # screen.fill(preto)
    # desenha_texto(screen, "SE PREPARE!", 40, LAR/2, ALTURA/2)
    # pygame.display.update()
    

def desenha_texto(surf, text, size, x, y):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, True, branco)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)


# def draw_shield_bar(surf, x, y, pct):
#     # if pct < 0:
#     #     pct = 0
#     pct = max(pct, 0) 
#     ## moving them to top
#     # BAR_LENGTH = 100
#     # BAR_HEIGHT = 10
#     fill = (pct / 100) * BAR_LENGTH
#     outline_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
#     fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
#     pygame.draw.rect(surf, GREEN, fill_rect)
#     pygame.draw.rect(surf, WHITE, outline_rect, 2)


def desenha_vidas(surf, x, y, vidas, img):
    for k in range(vidas):
        img_rect= img.get_rect()
        img_rect.x = x + 30 * k
        img_rect.y = y
        surf.blit(img, img_rect)


def novo_inimigo():
    inimigo_elemento = Inimigo()
    all_sprites.add(inimigo_elemento)
    Inimigo.add(inimigo_elemento)

# class Explosion(pygame.sprite.Sprite):
#     def __init__(self, center, size):
#         pygame.sprite.Sprite.__init__(self)
#         self.size = size
#         self.image = explosion_anim[self.size][0]
#         self.rect = self.image.get_rect()
#         self.rect.center = center
#         self.frame = 0 
#         self.last_update = pygame.time.get_ticks()
#         self.frame_rate = 75

    # def atualiza(self):
    #     agora = pygame.time.get_ticks()
    #     if agora - self.last_update > self.frame_rate:
    #         self.last_update = agora
    #         self.frame += 1
    #         if self.frame == len(explosion_anim[self.size]):
    #             self.kill()
    #         else:
    #             center = self.rect.center
    #             self.image = explosion_anim[self.size][self.frame]
    #             self.rect = self.image.get_rect()
    #             self.rect.center = center


class Jogador(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(jogador_img, (50, 38))
        self.image.set_colorkey(preto)
        self.rect = self.image.get_rect()
        self.radius = 20
        self.rect.centerx = LAR / 2
        self.rect.bottom = ALTURA - 10
        self.velx = 0 
        self.shield = 100
        self.atira_delay = 250
        self.last_shot = pygame.time.get_ticks()
        self.lives = 3
        self.hidden = False
        self.hide_timer = pygame.time.get_ticks()
        self.power = 1
        self.power_timer = pygame.time.get_ticks()

    def atualiza(self):
        if self.power >=2 and pygame.time.get_ticks() - self.power_time > POWERUP_TEMPO:
            self.power -= 1
            self.power_time = pygame.time.get_ticks()
 
        if self.hidden and pygame.time.get_ticks() - self.hide_timer > 1000:
            self.hidden = False
            self.rect.centerx = LAR / 2
            self.rect.bottom = ALTURA - 30

        self.velx = 0     

        status_key = pygame.key.get_pressed()     
        if status_key[pygame.K_LEFT]:
            self.velx = -5
        elif status_key[pygame.K_RIGHT]:
            self.velx = 5

        #atira segurando barra espaço
        if status_key[pygame.K_SPACE]:
            self.atira()

        #verifica as bordas da tela
        if self.rect.right > LAR:
            self.rect.right = LAR
        if self.rect.left < 0:
            self.rect.left = 0

        self.rect.x += self.velx

    def atira(self):
        agora = pygame.time.get_ticks()
        if agora - self.last_tiro > self.atira_delay:
            self.last_tiro = agora
            if self.power == 1:
                bullet = Gota(self.rect.centerx, self.rect.top)
                all_sprites.add(bullet)
                gotas.add(bullet)
                som_atirando.play()
            if self.power == 2:
                bullet1 = Gota(self.rect.left, self.rect.centery)
                bullet2 = Gota(self.rect.right, self.rect.centery)
                all_sprites.add(bullet1)
                all_sprites.add(bullet2)
                gotas.add(bullet1)
                gotas.add(bullet2)
                som_atirando.play()

            if self.power >= 3:
                bullet1 = Gota(self.rect.left, self.rect.centery)
                bullet2 = Gota(self.rect.right, self.rect.centery)
                # missile1 = Missile(self.rect.centerx, self.rect.top) 
                all_sprites.add(bullet1)
                all_sprites.add(bullet2)
                # all_sprites.add(missile1)
                gotas.add(bullet1)
                gotas.add(bullet2)
                # bullets.add(missile1)
                som_atirando.play()
                # missile_sound.play()

    def powerup(self):
        self.power += 1
        self.power_time = pygame.time.get_ticks()

    def hide(self):
        self.hidden = True
        self.hide_timer = pygame.time.get_ticks()
        self.rect.center = (LAR / 2, ALTURA + 200)


# defines the enemies
class Inimigo(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image_orig = random.choice(virus_images)
        self.image_orig.set_colorkey(preto)
        self.image = self.image_orig.copy()
        self.rect = self.image.get_rect()
        self.radius = int(self.rect.width *.90 / 2)
        self.rect.x = random.randrange(0, LAR - self.rect.width)
        self.rect.y = random.randrange(-150, -100)
        self.speedy = random.randrange(5, 20)        
        
        #deixar velocidade aleatoria

        self.velx = random.randrange(-3, 3)

        #rotação
        self.rotation = 0
        self.rotation_speed = random.randrange(-8, 8)
        self.last_update = pygame.time.get_ticks() 
        
    def rotate(self):
        time_agora = pygame.time.get_ticks()
        if time_agora - self.last_update > 50: 
            self.last_update = time_agora
            self.rotation = (self.rotation + self.rotation_speed) % 360 
            new_image = pygame.transform.rotate(self.image_orig, self.rotation)
            old_center = self.rect.center
            self.image = new_image
            self.rect = self.image.get_rect()
            self.rect.center = old_center

    def atualiza(self):
        self.rotate()
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        

        if (self.rect.top > ALTURA + 10) or (self.rect.left < -25) or (self.rect.right > LAR + 20):
            self.rect.x = random.randrange(0, LAR - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)


class Powerup(pygame.sprite.Sprite):
    def __init__(self, center):
        pygame.sprite.Sprite.__init__(self)
        self.type = random.choice(['escudo', 'arma'])
        self.image = powerup_images[self.type]
        self.image.set_colorkey(preto)
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.vely = 2

    def atualiza(self):
        self.rect.y += self.vely
        if self.rect.top > ALTURA:
            self.kill()


class Gota(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = gota_img
        self.image.set_colorkey(preto)
        self.rect = self.image.get_rect()
        self.rect.bottom = y 
        self.rect.centerx = x
        self.vely = -10

    def atualiza(self):
        self.rect.y += self.vely
        if self.rect.bottom < 0:
            self.kill()

# baixa as imagens
fundo = pygame.image.load(path.join(img_dir, 'space2.png')).convert()
fundo_rect = fundo.get_rect()

jogador_img = pygame.image.load(path.join(img_dir, 'seringa.png')).convert()
jogador_mini_img = pygame.transform.scale(jogador_img, (25, 19))
jogador_mini_img.set_colorkey(preto)
gota_img = pygame.image.load(path.join(img_dir, 'gota.png')).convert()


virus_images = []
virus_list = [
    'virus1.png',
    'virus2.png', 
    'virus3.png']

for image in virus_list:
    virus_images.append(pygame.image.load(path.join(img_dir, image)).convert())

#baixar power ups
powerup_images = {}
powerup_images['escudo'] = pygame.image.load(path.join(img_dir, 'escudo.png')).convert()
powerup_images['arma'] = pygame.image.load(path.join(img_dir, 'arma.png')).convert()


som_atirando = pygame.mixer.Sound(path.join(sons_dir, 'Atirar.wav'))

jogador_morre_som = pygame.mixer.Sound(path.join(sons_dir, 'dano_nave.wav'))

#loop principal do jogo
run = True
menu_display = True
while run:
    if menu_display:
        menu_principal()
        pygame.time.wait(3000)

        pygame.mixer.music.stop()
        pygame.mixer.music.load(path.join(sons_dir, 'principal.wav'))
        pygame.mixer.music.play(-1)
        
        menu_display = False
        
        all_sprites = pygame.sprite.Group()
        jogador = Jogador()
        all_sprites.add(jogador)

        inimigos = pygame.sprite.Group()
        for i in range(5):
            novo_inimigo()

        gotas = pygame.sprite.Group()
        powerups = pygame.sprite.Group()

        score = 0
        
    clock.tick(DT)
    for event in pygame.event.get():        
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                run = False

    all_sprites.update()


    colisões = pygame.sprite.groupcollide(inimigos, gotas, True, True)
    for colisão in colisões:
        score += 10 - colisão.radius         
        # random.choice(expl_sounds).play()
        # expl = Explosion(hit.rect.center, 'lg')
        # all_sprites.add(expl)
        if random.random() > 0.9:
            pow = Powerup(colisão.rect.center)
            all_sprites.add(pow)
            powerups.add(pow)
        novo_inimigo()       

    colisões = pygame.sprite.spritecollide(jogador, inimigos, True, pygame.sprite.collide_circle)
    for colisão in colisões:
        jogador.shield -= colisão.radius * 2
        # expl = Explosion(hit.rect.center, 'sm')
        # all_sprites.add(expl)
        novo_inimigo()
        if jogador.shield <= 0: 
            jogador_morre_som.play()
            # death_explosion = Explosion(jogador.rect.center, 'player')
            # all_sprites.add(death_explosion)
            jogador.hide()
            jogador.lives -= 1
            jogador.shield = 100

    colisões = pygame.sprite.spritecollide(jogador, powerups, True)
    for colisão in colisões:
        if colisão.type == 'escudo':
            jogador.shield += random.randrange(10, 30)
            if jogador.shield >= 100:
                jogador.shield = 100
        if colisão.type == 'arma':
            jogador.powerup()

    if jogador.lives == 0:  #and not death_explosion.alive():
        run = False

    screen.fill(preto)
    screen.blit(fundo, fundo_rect)

    all_sprites.draw(screen)
    desenha_texto(screen, str(score), 18, LAR / 2, 10)
    # draw_shield_bar(screen, 5, 5, player.shield)

    desenha_vidas(screen, LAR - 100, 5, jogador.vidas, jogador_mini_img)

    pygame.display.flip()       

pygame.quit()